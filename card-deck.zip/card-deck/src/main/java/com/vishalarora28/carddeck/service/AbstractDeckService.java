package com.vishalarora28.carddeck.service;

import com.vishalarora28.carddeck.domain.Deck;
import com.vishalarora28.carddeck.repository.DeckRepo;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractDeckService implements DeckService {

    protected DeckRepo deckRepo;

    @Inject
    public void setDeckRepo(DeckRepo deckRepo){
        this.deckRepo = deckRepo;
    }

    @Override
    public void putDeck(String deckName) {
        String [] suits = {"heart", "diamond", "club", "spade"};
        String [] values = {"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
        List<String> deck = new ArrayList<>();
        for (String suit:suits
                ) {
            for(String value:values
                    ){
                deck.add(value+"-"+suit);
            }

        }
        deckRepo.upsertDeck(new Deck(deckName,deck));
    }

    @Override
    public List<String> getAllDeckNames() {
        return deckRepo.getAllDeckNames();
    }

    @Override
    public List<String> getDeck(String deckName) {
        return deckRepo.getDeck(deckName);
    }

    @Override
    public void deleteDeck(String deckName) {
        deckRepo.deleteDeck(deckName);
    }
}
