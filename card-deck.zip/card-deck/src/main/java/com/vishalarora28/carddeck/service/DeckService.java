package com.vishalarora28.carddeck.service;

import java.util.List;

public interface DeckService {
    void putDeck(String deckName);
    void shuffleDeck(String deckName);
    List<String> getAllDeckNames();
    List<String> getDeck(String deckName);
    void deleteDeck(String deckName);

}
