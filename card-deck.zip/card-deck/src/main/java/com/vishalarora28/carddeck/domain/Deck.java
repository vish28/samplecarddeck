package com.vishalarora28.carddeck.domain;

import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class Deck {
    private String name;
    private List<String> deck;
}
