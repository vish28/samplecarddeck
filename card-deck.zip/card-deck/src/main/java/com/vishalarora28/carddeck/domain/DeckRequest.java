package com.vishalarora28.carddeck.domain;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class DeckRequest {
    @NonNull
    private String deckName;
}
