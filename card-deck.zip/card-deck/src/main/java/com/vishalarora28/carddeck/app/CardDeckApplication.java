package com.vishalarora28.carddeck.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.vishalarora28.carddeck")
public class CardDeckApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardDeckApplication.class, args);
	}
}
