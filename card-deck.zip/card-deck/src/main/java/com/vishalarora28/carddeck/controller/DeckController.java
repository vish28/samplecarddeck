package com.vishalarora28.carddeck.controller;

import com.vishalarora28.carddeck.domain.DeckRequest;
import com.vishalarora28.carddeck.service.DeckService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.util.List;

@RestController
public class DeckController {

    private DeckService deckService;

    @Inject
    public DeckController(DeckService deckService){
        this.deckService = deckService;
    }

    @RequestMapping(method = RequestMethod.PUT,
            path = "/deck")
    @ResponseStatus(value = HttpStatus.CREATED)
    public void putDeck(@Valid @RequestBody DeckRequest deckRequest){
        deckService.putDeck(deckRequest.getDeckName());
    }

    @RequestMapping(method = RequestMethod.POST,
            path = "/deck/shuffle")
    @ResponseStatus(value = HttpStatus.ACCEPTED)
    public void shuffleDeck(@Valid @RequestBody DeckRequest deckRequest){
        deckService.shuffleDeck(deckRequest.getDeckName());
    }

    @RequestMapping(method = RequestMethod.GET,
            path = "/deck/all")
    @ResponseStatus(value = HttpStatus.OK)
    public List<String> getAllDeckNames(){
        return deckService.getAllDeckNames();
    }

    @RequestMapping(method = RequestMethod.GET,
            path = "/deck/{name}")
    @ResponseStatus(value = HttpStatus.OK)
    public List<String> getDeck(@PathVariable("name") String deckName){
        return deckService.getDeck(deckName);
    }

    @RequestMapping(method = RequestMethod.DELETE,
            path = "/deck/{name}")
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void deleteDeck(@PathVariable("name") String deckName){
        deckService.deleteDeck(deckName);
    }

}
