package com.vishalarora28.carddeck.repository;

import com.vishalarora28.carddeck.domain.Deck;
import lombok.experimental.var;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Named
public class DeckRepoImpl implements DeckRepo {

    private static Map<String, List<String>> cardDecks = new HashMap<>();

    @Override
    public void upsertDeck(Deck deck) {
        if(cardDecks.containsKey(deck.getName())){
            cardDecks.replace(deck.getName(),deck.getDeck());
        }
        else{
            cardDecks.put(deck.getName(),deck.getDeck());
        }
    }

    @Override
    public List<String> getDeck(String deckName) {
        return cardDecks.get(deckName);
    }

    @Override
    public void deleteDeck(String deckName) {
        cardDecks.remove(deckName);
    }

    @Override
    public List<String> getAllDeckNames() {
        return new ArrayList<>(cardDecks.keySet());
    }
}
