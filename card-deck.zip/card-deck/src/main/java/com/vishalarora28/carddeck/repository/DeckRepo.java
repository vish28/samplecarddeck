package com.vishalarora28.carddeck.repository;

import com.vishalarora28.carddeck.domain.Deck;

import java.util.List;

public interface DeckRepo {
    void upsertDeck(Deck deck);
    List<String> getDeck(String deckName);
    void deleteDeck(String deckName);
    List<String> getAllDeckNames();
}
