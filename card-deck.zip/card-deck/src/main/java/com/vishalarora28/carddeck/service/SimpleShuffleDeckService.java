package com.vishalarora28.carddeck.service;

import com.vishalarora28.carddeck.domain.Deck;
import org.springframework.context.annotation.Profile;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

@Named
@Profile("simple-shuffle")
public class SimpleShuffleDeckService extends AbstractDeckService{

    @Override
    public void shuffleDeck(String deckName) {
        List<String> deck = deckRepo.getDeck(deckName);
        int random = (int)Math.random()*5+5;
        for (int i=0;i<random;i++){
            deck = shuffle(deck);
        }
        deckRepo.upsertDeck(new Deck(deckName,deck));
    }

    public List<String> shuffle(List<String> deck){
        int random = (int)Math.random()*10+5;
        List<String> shuffledDeck = new ArrayList<>();
        shuffledDeck.addAll(deck.subList(random,deck.size()));
        shuffledDeck.addAll(deck.subList(0,random-1));
        return shuffledDeck;
    }
}
