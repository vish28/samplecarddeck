package com.vishalarora28.carddeck.repository;

import com.vishalarora28.carddeck.domain.Deck;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@SpringBootTest
public class CardDeckRepositoryTests {

    @Test
    public void should_be_able_to_insert_new_deck(){
        DeckRepo deckRepo = new DeckRepoImpl();
        List<String> cardDeck = new ArrayList<>();
        cardDeck.add("1-heart");
        cardDeck.add("2-spade");
        Deck deck = new Deck("testDeck1", cardDeck);
        deckRepo.upsertDeck(deck);
        Deck repoDeck = new Deck("testDeck1",deckRepo.getDeck("testDeck1"));
        Assert.assertEquals(deck,repoDeck);
    }

    @Test
    public void should_be_able_to_update_deck(){
        DeckRepo deckRepo = new DeckRepoImpl();
        List<String> cardDeck = new ArrayList<>();
        cardDeck.add("1-heart");
        cardDeck.add("2-spade");
        Deck deck = new Deck("testDeck1", cardDeck);
        deckRepo.upsertDeck(deck);
        cardDeck.add("K-diamond");
        deck.setDeck(cardDeck);
        deckRepo.upsertDeck(deck);
        Deck repoDeck = new Deck("testDeck1",deckRepo.getDeck("testDeck1"));
        Assert.assertEquals(deck,repoDeck);
    }

    @Test
    public void should_be_able_to_delete_deck(){
        DeckRepo deckRepo = new DeckRepoImpl();
        List<String> cardDeck = new ArrayList<>();
        cardDeck.add("1-heart");
        cardDeck.add("2-spade");
        Deck deck = new Deck("testDeck1", cardDeck);
        deckRepo.upsertDeck(deck);
        deckRepo.deleteDeck("testDeck1");

        Assert.assertFalse(deckRepo.getAllDeckNames().contains("testDeck1"));
    }
}
