package com.vishalarora28.carddeck.app;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {CardDeckApplication.class})
@ActiveProfiles("simple-shuffle")
public class CardDeckApplicationTests {

	@Test
	public void contextLoads() {
	}

}
